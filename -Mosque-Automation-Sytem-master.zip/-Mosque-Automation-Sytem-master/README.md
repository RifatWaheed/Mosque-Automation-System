# Mosque-Automation-Sytem
A microcontroller based project where a mosque automation system was built
Using:  Arduino Mega and a couple of different sensors
